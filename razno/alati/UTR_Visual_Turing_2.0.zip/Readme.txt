VISUAL TURING MACHINE
Version 2.0

Author: Csaba Gajo <gcsaba2@freemail.hu>
Date: May 30th, 2007

Thank you for using Visual Turing, version 2.0. This is an open-source project, which means you can distribute it freely and modify its code, as long as you don't remove my name from any part of the software :)
You can always read Licence.txt for an official legal document of what you can and can't do.

Please read the Help file for information about this program. I will hopefully write a better documentation when I'll have some time.

==========================================

HOW TO START???

You need to double-click on the "Turing" icon. That's it.
If this doesn't work for you, then:
 - you don't have Java 1.4 installed. Download from http://www.java.com/getjava/
 - you didn't install Java properly. Try again!
 - you have an old version of Java. You must have at least Java 1.4
 - if nothing else works, try running it from your command prompt. Do this:
      a) Click on Window's Start button
      b) Click on Run
      c) Type in "cmd"
      d) Go to the directory where the files are, for example C:\Turing
      e) Type in "java -jar Turing.jar"

    This should work under Windows XP. For other systems contact me or someone who uses that other system.

==========================================


TRANSLATION

If you would like to translate this application to your own native language, all you have to do is edit the "text.properties" file. Please write to me that you did this and I'll add your version to the official repository.




