package revers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Pocetna {
	public static void main(final String[] args) throws IOException {
		if (args.length < 1) {
			System.out.println("Potreban argument: ime ulazne datoteke!");
			return;
		}

		final BufferedReader reader = new BufferedReader(new FileReader(args[0]));
		final String trakaLine = reader.readLine();

		if (trakaLine == null || "".equals(trakaLine.trim())) {
			System.out.println("Neispravno zadana ulazna traka!");
			return;
		}

		final Automat automat = new Automat(trakaLine);
		automat.pokreni();
		// automat.ispisiPrijelaze();
	}
}
