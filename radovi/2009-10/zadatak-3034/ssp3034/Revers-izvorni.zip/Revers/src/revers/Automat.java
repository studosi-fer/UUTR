package revers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import revers.Automat.Glava.Pomak;
import revers.Automat.Stanje.Prijelaz;

public class Automat {

	private final Map<String, Stanje>	m_stanja;

	private final List<Glava>			m_glave;

	private final String				m_pocetnoStanje	= "q-prepis";

	private final String				m_zavrsnoStanje	= "prihvati";

	public Automat(final String p_trakaLine) {
		m_stanja = new LinkedHashMap<String, Stanje>();
		m_glave = new ArrayList<Glava>();

		m_glave.add(new Glava(p_trakaLine));

		final LinkedList<String> drugaTraka = new LinkedList<String>(m_glave.get(0).m_traka);
		for (int i = 0; i < drugaTraka.size(); i++) {
			drugaTraka.set(i, "B");
		}

		m_glave.add(new Glava(drugaTraka));

		try {
			stanja();
		} catch (final IOException e) {
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public void ispisiPrijelaze() {
		for (final Entry<String, Stanje> entry : m_stanja.entrySet()) {
			final Stanje stanje = entry.getValue();
			for (final Entry<List<String>, Prijelaz> prijelaz : stanje.getStanja().entrySet()) {
				System.out.println("(" + entry.getKey() + ", " + prijelaz.getKey() + ")" + " -> " + prijelaz.getValue());
			}
		}
	}

	public void pokreni() {
		Stanje trenutnoStanje = m_stanja.get(m_pocetnoStanje);

		while (true) {
			final List<String> ulazniZnak = trenutniZnak();

			final Prijelaz prijelaz = trenutnoStanje.dohvatiPrijelaz(ulazniZnak);

			ispisSadrzajTraka();

			if (prijelaz == null) {
				System.out.println("TS ne prihvaca ulazni niz!");
				return;
			}

			napraviPrijelaz(prijelaz);

			final String slijedeceStanje = prijelaz.getNovoStanje();
			if (slijedeceStanje.equals(m_zavrsnoStanje)) {
				System.out.println("TS prihvaca ulazni niz!");
				break;
			}

			System.out.println("(" + trenutnoStanje + ", " + ulazniZnak + ") -> (" + prijelaz.getNovoStanje() + ", " + prijelaz.getZnak() + ", " + prijelaz.getPomak() + ")");

			if (slijedeceStanje != null) {
				trenutnoStanje = m_stanja.get(slijedeceStanje);
			} else {
				System.out.println("TS ne prihavaca ulazni niz!");
				return;
			}

			System.out.println();
		}
	}

	private void ispisSadrzajTraka() {
		for (int i = 0; i < m_glave.size(); i++) {
			System.out.println(m_glave.get(i).m_traka);

			final LinkedList<String> pokazivac = new LinkedList<String>(m_glave.get(i).m_traka);
			pokazivac.set(m_glave.get(i).m_trenutnaPozicija, "*");
			for (int j = 0; j < pokazivac.size(); j++) {
				if (!pokazivac.get(j).equals("*")) {
					pokazivac.set(j, " ");
				}
			}

			System.out.println(pokazivac);
		}
	}

	private void napraviPrijelaz(final Prijelaz p_prijelaz) {
		for (int i = 0; i < m_glave.size(); i++) {
			m_glave.get(i).napraviPomak(p_prijelaz, i);
		}
	}

	private List<String> trenutniZnak() {
		final List<String> znak = new ArrayList<String>(2);
		for (int i = 0; i <= 1; i++) {
			znak.add(m_glave.get(i).trenutniZnak());
		}

		return znak;
	}

	private void stanja() throws IOException {
		final BufferedReader reader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("definicija.txt")));

		while (true) {
			String line = reader.readLine();
			if (line == null) {
				break;
			}

			final String[] st = line.split(" "); // stanja
			line = reader.readLine();
			final String[] traka1 = line.split(" ");
			line = reader.readLine();
			final String[] traka2 = line.split(" ");

			final Stanje stanje = dohvatiliIliStvoriStanje(st[0]);
			final List<String> izlazZnak = new ArrayList<String>();
			final List<String> ulazZnak = new ArrayList<String>();
			final List<Pomak> pomak = new ArrayList<Pomak>();

			ulazZnak.add(traka1[0]);
			ulazZnak.add(traka2[0]);
			izlazZnak.add(traka1[1]);
			izlazZnak.add(traka2[1]);
			pomak.add(Pomak.getPomakForString(traka1[2]));
			pomak.add(Pomak.getPomakForString(traka2[2]));

			final Prijelaz prijelaz = new Prijelaz(st[1], izlazZnak, pomak);
			stanje.dodajPrijelaz(ulazZnak, prijelaz);

			// m_stanja.put(stanje.getImeStanja(), stanje);

			line = reader.readLine();
			if (line != null && !line.trim().equals("")) {
				throw new IllegalStateException("Ulazna datoteka s definicijama nije po zadanom formatu!");
			} else if (line == null) {
				break;
			}
		}
	}

	private Stanje dohvatiliIliStvoriStanje(final String p_string) {
		Stanje stanje = m_stanja.get(p_string);

		if (stanje == null) {
			stanje = new Stanje(p_string);
			m_stanja.put(p_string, stanje);
		}

		return stanje;
	}

	public static class Glava {

		private final LinkedList<String>	m_traka;

		private int							m_trenutnaPozicija	= 1;

		public Glava(final String p_traka) {
			m_traka = new LinkedList<String>();

			for (int i = 0; i < p_traka.length(); i++) {
				m_traka.add(String.valueOf(p_traka.charAt(i)));
			}

			m_traka.addFirst("B");
		}

		public Glava(final LinkedList<String> p_traka) {
			m_traka = p_traka;
		}

		public void napraviPomak(final Prijelaz p_prijelaz, final int p_index) {
			final String znak = p_prijelaz.getZnak().get(p_index);
			final Pomak pomak = p_prijelaz.getPomak().get(p_index);

			if (m_trenutnaPozicija == m_traka.size() - 1) {
				m_traka.addLast("B");
			} else if (m_trenutnaPozicija == 0 && pomak.equals(Pomak.L)) {
				m_traka.addFirst("B");
				m_trenutnaPozicija++;
			}

			if (pomak.equals(Pomak.L)) {
				m_traka.set(m_trenutnaPozicija--, znak);

			} else if (pomak.equals(Pomak.D)) {
				m_traka.set(m_trenutnaPozicija++, znak);
			} else if (pomak.equals(Pomak.STOP)) {
				// preskoci
			} else {
				throw new IllegalStateException("Nepodrzani pomak!");
			}
		}

		public String trenutniZnak() {
			return m_traka.get(m_trenutnaPozicija);
		}

		public static enum Pomak {
			L("L"), D("R"), STOP("N");

			private String	m_oznaka;

			Pomak(final String p_oznaka) {
				m_oznaka = p_oznaka;
			}

			@Override
			public String toString() {
				return m_oznaka;
			}

			public static Pomak getPomakForString(final String p_pomak) {
				if (p_pomak.toUpperCase().equals(Pomak.L.toString())) {
					return Pomak.L;
				} else if (p_pomak.toUpperCase().equals(Pomak.D.toString())) {
					return Pomak.D;
				} else if (p_pomak.toUpperCase().equals(Pomak.STOP.toString())) {
					return Pomak.STOP;
				} else {
					throw new IllegalArgumentException("Nepoznat pomak " + p_pomak);
				}
			}
		}
	}

	public static class Stanje {

		private final String						m_imeStanja;

		private final Map<List<String>, Prijelaz>	m_stanja;

		public String getImeStanja() {
			return m_imeStanja;
		}

		public Stanje(final String p_imeStanja) {
			m_imeStanja = p_imeStanja;
			m_stanja = new LinkedHashMap<List<String>, Prijelaz>();
		}

		public void dodajPrijelaz(final List<String> p_ulazniZnak, final Prijelaz p_prijelaz) {
			m_stanja.put(p_ulazniZnak, p_prijelaz);
		}

		public Prijelaz dohvatiPrijelaz(final List<String> p_ulazni) {
			return m_stanja.get(p_ulazni);
		}

		@Override
		public String toString() {
			return m_imeStanja;
		}

		public Map<List<String>, Prijelaz> getStanja() {
			return m_stanja;
		}

		public static class Prijelaz {
			private final String		m_novoStanje;
			private final List<String>	m_znak;
			private final List<Pomak>	m_pomak;

			public Prijelaz(final String p_novoStanje, final List<String> p_znak, final List<Pomak> p_pomak) {
				super();
				m_novoStanje = p_novoStanje;
				m_znak = p_znak;
				m_pomak = p_pomak;
			}

			public String getNovoStanje() {
				return m_novoStanje;
			}

			public List<String> getZnak() {
				return m_znak;
			}

			public List<Pomak> getPomak() {
				return m_pomak;
			}

			@Override
			public String toString() {
				final StringBuilder sb = new StringBuilder();
				sb.append("(").append(m_novoStanje).append(", ").append(m_znak.toString()).append(", ").append(m_pomak.toString()).append(")");

				return sb.toString();
			}
		}
	}
}