#include<stdio.h>
#include<string.h>
#include<malloc.h>

typedef struct
{
	char trenutno_stanje;
	char ulazni_znak;
	char novo_stanje;
	char novi_znak;
	char pomak;
} prijelazi_turingovog_stroja;

struct
{
	int pokazivac_na_znak_s_ulazne_trake;
	char trenutno_stanje;
} turingov_stroj;

int main()
{

	int redni_broj_prijelaza, broj_prijelaza = 0, nasao_prijelaz = 0;
	char *ulazna_traka, znak;
	FILE *fp;
	prijelazi_turingovog_stroja *palindrom;
	
	turingov_stroj.pokazivac_na_znak_s_ulazne_trake = 0;

	ulazna_traka = (char *)malloc( (turingov_stroj.pokazivac_na_znak_s_ulazne_trake+1) * sizeof(char));
    printf("Upi�i niz znamenki broja: ");
	while(scanf("%c", &ulazna_traka[turingov_stroj.pokazivac_na_znak_s_ulazne_trake]))
	{
		if(ulazna_traka[turingov_stroj.pokazivac_na_znak_s_ulazne_trake] == '\n')
			break;
		turingov_stroj.pokazivac_na_znak_s_ulazne_trake++;
		ulazna_traka = (char *)realloc(ulazna_traka, (turingov_stroj.pokazivac_na_znak_s_ulazne_trake+1) * sizeof(char));
	}

	ulazna_traka[turingov_stroj.pokazivac_na_znak_s_ulazne_trake] = 'B';
	
	close(0);
	fp = fopen("dz2.prijelazi", "r");
	if(fp == NULL)
	{
		printf("Dogodila se gre�ka pri radu s datotekom. Pokaziva� na datoteku je NULL.\nIzlazim iz programa...");
		exit(0);
	}

    while(scanf("%c", &znak)!=-1)
		if(znak == '\n')
			broj_prijelaza++;
	palindrom = (prijelazi_turingovog_stroja *)malloc(broj_prijelaza*sizeof(prijelazi_turingovog_stroja));
	fseek(fp,0L,SEEK_SET);
	
	for(redni_broj_prijelaza = 0; redni_broj_prijelaza <= broj_prijelaza; redni_broj_prijelaza++)
	{
		scanf("%c ", &palindrom[redni_broj_prijelaza].trenutno_stanje);
		scanf("%c ", &palindrom[redni_broj_prijelaza].ulazni_znak);
		scanf("%c ", &palindrom[redni_broj_prijelaza].novo_stanje);
		scanf("%c ", &palindrom[redni_broj_prijelaza].novi_znak);
		scanf("%c ", &palindrom[redni_broj_prijelaza].pomak);
	}
	close(fp);

	turingov_stroj.trenutno_stanje = palindrom[0].trenutno_stanje;
	turingov_stroj.pokazivac_na_znak_s_ulazne_trake = 0;

	while(nasao_prijelaz != -1)
	{
		nasao_prijelaz = -1;
		for(redni_broj_prijelaza = 0; redni_broj_prijelaza < broj_prijelaza+1; redni_broj_prijelaza++)
			if(turingov_stroj.trenutno_stanje == palindrom[redni_broj_prijelaza].trenutno_stanje && ulazna_traka[turingov_stroj.pokazivac_na_znak_s_ulazne_trake] == palindrom[redni_broj_prijelaza].ulazni_znak)
			{
				nasao_prijelaz = redni_broj_prijelaza;
				break;
			}
		if(nasao_prijelaz != -1)
		{
			turingov_stroj.trenutno_stanje = palindrom[nasao_prijelaz].novo_stanje;
			ulazna_traka[turingov_stroj.pokazivac_na_znak_s_ulazne_trake] = palindrom[nasao_prijelaz].novi_znak;
			if(palindrom[nasao_prijelaz].pomak == 'R')
				turingov_stroj.pokazivac_na_znak_s_ulazne_trake++;
			else
				turingov_stroj.pokazivac_na_znak_s_ulazne_trake--;
		}
	}

	if(turingov_stroj.trenutno_stanje == 'K')
		printf("U�itani niz znakova je palindrom.");
	else
		printf("U�itani niz znakova nije palindrom.");

	return 0;
}