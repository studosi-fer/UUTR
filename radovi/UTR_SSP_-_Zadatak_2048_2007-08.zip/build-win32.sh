#!/bin/sh
wine "/mnt/hda1/Program Files/CodeBlocks/codeblocks.exe" --target="Release" --rebuild -ns tworing.cbp

