sazetak.html - popis stvari prođenih na predavanju i primjer implementacije DKA koji ne mijenja stanje kada ne postoji prijelaz

sazetak.md - Markdown datoteka iz koje je generiran gornji dokument

dka.py - automat kojeg smo napravili na predavanju s komentarima na mjestima koje treba promijeniti da bi se isti pretvorio u eNKA

program.py - kratak program s kojim smo isprobavali stvari na predavanju

ulaz*.txt - (jednaki) primjeri ulaza
izlaz*.txt - očekivani izlazi s napomenom da je izlaz2.txt neispravan kako bi pokazao grešku koja se pojavi prilikom testiranja

test.sh - skripta koja će pokrenuti ispitivanje programa i ispisati rezultate
