Ovaj dokument isklju�ivo slu�i namjeni kako bi pogao u izradi
3 labosa iz predmeta Uvod u teoriju ra�unarstva.
Ovaj zadatak odra�en je u programskom jeziku C#.

Otvara se kao solution u Visual Studiu.
Program je uzra�en u TuringovStroj\bin\Debug...
automat.txt = definicija automata
ulazi.txt = ulazni nizovi
out-*.txt = ispis svakog ulaznog niza

Ovaj dokument NIJE namjenjen prepisivanju i zlouporabi ve�
slu�i kao orijentir izgradnje TS u prog. jeziku C#