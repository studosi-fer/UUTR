Za C/C++/C#:
(1)	extractaj zip i kroz terminal se pozicioniraj tamo gdje je extractano
(2)	tamo kompajliraj svoj kod, izvrsna datoteka mora biti 'Parser' (npr. 'mono src.cs -o Parser' za C#, gcc za C, g++ za C++)
(3)	pokreni skriptu sa 'bash test_c.sh'

Za Python:
(1)	isto
(2)	tamo stavi i svoj kod 'Parser.py'
(3)	pokreni skriptu sa 'bash test_p.sh'

Za Javu:
(1)	isto
(2)	tamo kompajliraj kod (javac Parser.java)
(3)	pokreni skriptu sa 'bash test_j.sh'
