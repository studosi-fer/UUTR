#ifndef NOVOSTANJE_H_INCLUDED
#define NOVOSTANJE_H_INCLUDED

#include <string>

using namespace std;

struct NovoStanje {
    int indexNovogStanja;
    string znakNaStog;
};

#endif // NOVOSTANJE_H_INCLUDED
