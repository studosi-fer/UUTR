#ifndef PRIJELAZ_H_INCLUDED
#define PRIJELAZ_H_INCLUDED

#include <list>
#include "novoStanje.h"

using namespace std;

class Prijelaz {
private:
    char ulazniZnak, znakStoga;
    list<NovoStanje> prijelazi;
public:
    Prijelaz(char ulazniZnak, char znakStoga);
    void dodajPrijelaz(int novoStanje, string znakNaStog);
    const list<NovoStanje> getNovaStanja();
    char getUlazniZnak();
    char getZnakStoga();
    bool jesamLiTaj(char ulaz, char znakStoga);
    bool isNull();
};

#endif // PRIJELAZ_H_INCLUDED
