#include <algorithm>

#include "Konfiguracija.h"
#include "novoStanje.h"

Konfiguracija::Konfiguracija(string &noviStog, Stanje &novoStanje, char *preostaliUlaz, const char epsilon) {
    stog=noviStog;
    trenutnoStanje=novoStanje;
    neprocitaniDio=preostaliUlaz;
    this->epsilon=epsilon;
}

Konfiguracija::~Konfiguracija() {
    stog.clear();
}

void Konfiguracija::ispisiStog(bool novo, string noviZnak) {
    string pomoc=stog;
    reverse(pomoc.begin(), pomoc.end());
    if (novo) {
        cout << "Novo stanje stoga: ";
        if (noviZnak[0]!=epsilon)
            cout << noviZnak;
        cout << pomoc.substr(1) << endl;

    } else {
        cout << "Trenutno stanje stoga: " << pomoc << endl;
    }
}

void Konfiguracija::ispisiTrenutnoStanje() {
    cout << endl << "Trenutno stanje: q" << trenutnoStanje.getIme() << endl;
}

void Konfiguracija::ispisiNeprocitano(bool Epr) {
    cout << "Nepročitani dio ulaznog niza: " << (Epr ? neprocitaniDio : (neprocitaniDio+1)) << endl;
}

void Konfiguracija::ispisiPrijelaz(NovoStanje ns, bool epri) {
    if (epri)
        cout << "Obavljam prijelaz: delta(q" << trenutnoStanje.getIme() << ", " << "epsilon" << ", " << stog[stog.size()-1] <<
        ") --> (q" << ns.indexNovogStanja << ", " << (ns.znakNaStog[0]==epsilon ? "epsilon" : ns.znakNaStog) << ")" << endl;
    else
        cout << "Obavljam prijelaz: delta(q" << trenutnoStanje.getIme() << ", " << *neprocitaniDio << ", " << stog[stog.size()-1] <<
        ") --> (q" << ns.indexNovogStanja << ", " << (ns.znakNaStog[0]==epsilon ? "epsilon" : ns.znakNaStog) << ")" << endl;
}

list<Konfiguracija> Konfiguracija::obaviPrijelaz(vector<Stanje>& stanja) {
    list<Konfiguracija> noveKonfiguracije;
    EPrijelaz epr=trenutnoStanje.dohvatiEPrijelaz(stog[stog.size()-1]);
    if (!epr.isNull()) {
        list<NovoStanje> novaStanja=epr.getNovaStanja();
        for (list<NovoStanje>::iterator it=novaStanja.begin(); it!=novaStanja.end(); it++) {
            ispisiTrenutnoStanje();
            cout << "Učitani znak: epsilon" << endl;
            ispisiNeprocitano(true);
            ispisiStog(false, "");
            ispisiPrijelaz(*it, true);
            cout << "Prelazim u stanje: q" << it->indexNovogStanja << endl;
            ispisiStog(true, it->znakNaStog);
            Stanje novo=stanja[it->indexNovogStanja];
            if (novo.isPrihvatljivo())
                cout << "Do sada učitani niz se PRIHVAĆA prihvatljivim stanjem." << endl;
            else
                cout << "Do sada učitani niz se NE PRIHVAĆA prihvatljivim stanjem." << endl;
            if (it->znakNaStog[0]==epsilon && stog.size()==1) { // skinut će zadnji znak, a ništa neće staviti
                cout << "Do sada učitani niz se PRIHVAĆA praznim stogom." << endl;
            } else { // ovdje sigurno stog neće biti prazan, pa automat sigurno nastavlja rad
                cout << "Do sada učitani niz se NE PRIHVAĆA praznim stogom." << endl;
                string znakoviZaStog;
                if (it->znakNaStog[0]==epsilon) {
                    znakoviZaStog="";
                } else
                    znakoviZaStog=it->znakNaStog;
                reverse(znakoviZaStog.begin(), znakoviZaStog.end());
                string noviStog=stog.substr(0, stog.size()-1) + znakoviZaStog;
                Konfiguracija nova(noviStog, novo, neprocitaniDio, epsilon);
                noveKonfiguracije.push_back(nova);
            }
        }
    }
    Prijelaz pr=trenutnoStanje.dohvatiPrijelaz(*neprocitaniDio, stog[stog.size()-1]);
    if (!pr.isNull()) {
        list<NovoStanje> novaStanja=pr.getNovaStanja();
        for (list<NovoStanje>::iterator it=novaStanja.begin(); it!=novaStanja.end(); it++) {
            ispisiTrenutnoStanje();
            cout << "Učitani znak: ";
            if (*neprocitaniDio)
                cout << *neprocitaniDio << endl;
            else
                cout << "kraj ulaznog niza" << endl;
            ispisiNeprocitano(false);
            ispisiStog(false, "");
            ispisiPrijelaz(*it, false);
            cout << "Prelazim u stanje: q" << it->indexNovogStanja << endl;
            ispisiStog(true, it->znakNaStog);
            Stanje novo=stanja[it->indexNovogStanja];
            if (novo.isPrihvatljivo())
                cout << "Do sada učitani niz se PRIHVAĆA prihvatljivim stanjem." << endl;
            else
                cout << "Do sada učitani niz se NE PRIHVAĆA prihvatljivim stanjem." << endl;
            if (it->znakNaStog[0]==epsilon && stog.size()==1) { // skinut će zadnji znak, a ništa neće staviti
                cout << "Do sada učitani niz se PRIHVAĆA praznim stogom." << endl;
            } else { // ovdje sigurno stog neće biti prazan, pa automat nastavlja rad ako ulazni znak nije kraj reda
                cout << "Do sada učitani niz se NE PRIHVAĆA praznim stogom." << endl;
                if (*neprocitaniDio) { // ako nije kraj ulaznog niza, onda generiraj novu konfiguraciju, inače je gotovo
                    string znakoviZaStog;
                    if (it->znakNaStog[0]==epsilon) {
                        znakoviZaStog="";
                    } else
                        znakoviZaStog=it->znakNaStog;
                    reverse(znakoviZaStog.begin(), znakoviZaStog.end());
                    string noviStog=stog.substr(0, stog.size()-1) + znakoviZaStog;
                    Konfiguracija nova(noviStog, novo, neprocitaniDio+1, epsilon);
                    noveKonfiguracije.push_back(nova);
                }
            }
        }
    }
    return noveKonfiguracije;
}
