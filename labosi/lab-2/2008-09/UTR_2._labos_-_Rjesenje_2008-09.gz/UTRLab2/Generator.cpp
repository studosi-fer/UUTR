#include <iostream>
#include <fstream>

using namespace std;

int main() {
    int br_stanja;
    char epsilon, stackBegin;
    char imeDat[50];
    cout << "Unesi ime datoteke u koju želiš spremiti automat > ";
    cin.getline(imeDat, 50);
    ofstream os(imeDat);
    cout << "Program za generiranje NPA" << endl;
    cout << "Koliko stanja želiš? > ";
    cin >> br_stanja;
    cin.ignore(15, '\n');
    cout << "Kojim znakom želiš označiti prazni znak (epsilon)? > ";
    cin >> epsilon;
    cin.ignore(15, '\n');
    cout << "Koji znak će biti početni na stogu? > ";
    cin >> stackBegin;
    cin.ignore(15,'\n');
    os << br_stanja << '\t' << epsilon << '\t' << stackBegin << endl;
    for (int i=0; i<br_stanja; i++) {
        cout << endl << "Definiranje stanja " << i << endl;
        cout << "Je li stanje prihvatljivo? (d/n) > ";
        char odgovor;
        cin>>odgovor;
        cin.ignore(15,'\n');
        os << "Stanje:" << i << '\t' << (odgovor=='d' ? 'P' : 'N') << endl;
        cout << "Želiš li dodati epsilon-prijelaz za stanje " << i << "? (d/n) > ";
        cin >> odgovor;
        cin.ignore(15, '\n');
        while (odgovor=='d') { // dodavanje e-prijelaza
            cout << "Uz koji znak na stogu želiš epsilon prijelaz za stanje " << i << "? > ";
            char znak;
            cin>>znak;
            cin.ignore(15, '\n');
            os << "EPrijelaz:"<<znak<<endl;
            odgovor='d';
            while (odgovor=='d') {
                cout << "U koje stanje želiš prijeći? (upiši broj: indeks stanja) > ";
                int novoStanje;
                cin>>novoStanje;
                cin.ignore(15,'\n');
                cout << "Koje znakove želiš staviti na stog pri prijelazu (max 50)? > ";
                char znak2[50];
                cin.getline(znak2, 50);
         //       cin.ignore(15, '\n');
                os << novoStanje << '\t' << znak2 << endl;
                cout << "Želiš li za taj epsilon-prijelaz dodati još jedno stanje u koje se prelazi? (d/n) > ";
                cin>>odgovor;
                cin.ignore(15,'\n');
            }
            os << "EndEPrijelaz" << endl;
            cout << "Želiš li dodati još jedan epsilon-prijelaz za stanje " << i << "? (d/n) > ";
            cin>>odgovor;
            cin.ignore(15, '\n');
        }
        cout << "Želiš li dodati prijelaz za stanje " << i << "? (d/n) > ";
        cin>>odgovor;
        cin.ignore(15, '\n');
        while(odgovor=='d') { // dodavanje prijelaza
            cout << "Koji znak je potrebno pročitati za taj prijelaz? > ";
            char ulazniZnak;
            cin>>ulazniZnak;
            cin.ignore(15, '\n');
            cout << "Uz koji znak na stogu se događa taj prijelaz? > ";
            char znakStoga;
            cin>>znakStoga;
            cin.ignore(15, '\n');
            os << "Prijelaz:" << ulazniZnak << '\t' << znakStoga << endl;
            odgovor='d';
            while (odgovor=='d') {
                cout << "U koje stanje želiš prijeći? (upiši broj: indeks stanja) > ";
                int novoStanje;
                cin>>novoStanje;
                cin.ignore(15,'\n');
                cout << "Koje znakove želiš staviti na stog pri prijelazu (max 50)? > ";
                char znak2[50];
                cin.getline(znak2, 50);
             //   cin.ignore(15, '\n');
                os << novoStanje << '\t' << znak2 << endl;
                cout << "Želiš li za taj prijelaz dodati još jedno stanje u koje se prelazi? (d/n) > ";
                cin>>odgovor;
                cin.ignore(15,'\n');
            }
            os << "EndPrijelaz" << endl;
            cout << "Želiš li dodati još jedan prijelaz za stanje " << i << "? (d/n) > ";
            cin>>odgovor;
            cin.ignore(15, '\n');
        }
        os << "EndStanje" << endl;
    }
    os.close();
    cout << endl << "Automat izgeneriran u datoteci " << imeDat << endl;
    return 0;
}
