#include "Prijelaz.h"

Prijelaz::Prijelaz(char ulazniZnak, char znakStoga) {
    this->ulazniZnak=ulazniZnak;
    this->znakStoga=znakStoga;
}

bool Prijelaz::isNull() {
    if(ulazniZnak==0 && znakStoga==0)
        return true;
    else
        return false;
}

void Prijelaz::dodajPrijelaz(int novoStanje, string znakNaStog) {
    NovoStanje ns;
    ns.indexNovogStanja=novoStanje;
    ns.znakNaStog=znakNaStog;
    prijelazi.push_back(ns);
}

const list<NovoStanje> Prijelaz::getNovaStanja() {
    return prijelazi;
}

char Prijelaz::getZnakStoga() {
    return znakStoga;
}

char Prijelaz::getUlazniZnak() {
    return ulazniZnak;
}

bool Prijelaz::jesamLiTaj(char ulaz, char znakStoga) {
    return ulaz==ulazniZnak && this->znakStoga==znakStoga;
}
