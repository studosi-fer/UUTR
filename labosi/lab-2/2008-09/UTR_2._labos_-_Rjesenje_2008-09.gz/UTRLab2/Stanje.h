#ifndef STANJE_H_INCLUDED
#define STANJE_H_INCLUDED

#include <vector>

#include "EPrijelaz.h"
#include "Prijelaz.h"

using namespace std;

class Stanje {
private:
        bool prihvatljivo;
        int imeStanja;
        vector<EPrijelaz> eprijelazi;
        vector<Prijelaz> prijelazi;
public:
        Stanje() {}
        Stanje(bool prihvatljivost, int imeStanja);
        void dodajEPrijelaz(EPrijelaz novi);
        void dodajPrijelaz(Prijelaz novi);
        EPrijelaz dohvatiEPrijelaz(char znakNaStogu);
        Prijelaz dohvatiPrijelaz(char ulazniZnak, char znakNaStogu);
        int getIme();
        bool isPrihvatljivo();
        ~Stanje();
};

#endif // STANJE_H_INCLUDED
