#include "Stanje.h"

Stanje::Stanje(bool prihvatljivost, int imeStanja) {
    prihvatljivo=prihvatljivost;
    this->imeStanja=imeStanja;
}

int Stanje::getIme() {
    return imeStanja;
}

Stanje::~Stanje() {
    eprijelazi.clear();
    prijelazi.clear();
}

bool Stanje::isPrihvatljivo() {
    return prihvatljivo;
}

void Stanje::dodajEPrijelaz(EPrijelaz novi) {
    eprijelazi.push_back(novi);
}

void Stanje::dodajPrijelaz(Prijelaz novi) {
    prijelazi.push_back(novi);
}

EPrijelaz Stanje::dohvatiEPrijelaz(char znakNaStogu) {
    for(vector<EPrijelaz>::iterator it=eprijelazi.begin(); it!=eprijelazi.end(); it++) {
        if(it->jesamLiTaj(znakNaStogu))
            return *it;
    }
    EPrijelaz null(0);
    return null;
}

Prijelaz Stanje::dohvatiPrijelaz(char ulazniZnak, char znakNaStogu) {
    for(vector<Prijelaz>::iterator it=prijelazi.begin(); it!=prijelazi.end(); it++) {
        if(it->jesamLiTaj(ulazniZnak, znakNaStogu))
            return *it;
    }
    Prijelaz null(0,0);
    return null;
}
