#include "EPrijelaz.h"

EPrijelaz::EPrijelaz(char znakStoga) {
    this->znakStoga=znakStoga;
}

void EPrijelaz::dodajPrijelaz(int novoStanje, string znakNaStog) {
    NovoStanje ns;
    ns.indexNovogStanja=novoStanje;
    ns.znakNaStog=znakNaStog;
    prijelazi.push_back(ns);
}

const list<NovoStanje> EPrijelaz::getNovaStanja() {
    return prijelazi;
}

char EPrijelaz::getZnakStoga() {
    return znakStoga;
}

bool EPrijelaz::jesamLiTaj(char znakStoga) {
    return this->znakStoga==znakStoga;
}

bool EPrijelaz::isNull() {
    if(znakStoga==0)
        return true;
    else
        return false;
}
