#include <list>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>

#include "Stanje.h"
#include "EPrijelaz.h"
#include "Prijelaz.h"
#include "Konfiguracija.h"

using namespace std;

void simulate(vector<Stanje> &stanja, char pocZnakStoga, char epsilon);

int main() {
    char epsilon, pocZnakStoga;
    int br_stanja;
    char p[50];
    vector<Stanje> stanja;
    char imeDat[50];
    cout << "Unesi ime datoteke gdje je pohranjen automat > ";
    cin.getline(imeDat,50);
    ifstream is(imeDat);
    if(is.fail()) {
        cout << "Datoteka " << imeDat << " ne postoji ili ne može biti učitana!" << endl;
        exit(1);
    }
    // učitavanje automata
    cout << "Učitavam automat iz datoteke " << imeDat << "..." << endl;
    is>>br_stanja>>epsilon>>pocZnakStoga;
    is.ignore(15,'\n');
    stanja.reserve(br_stanja);
    for (int i=0; i<br_stanja; i++) {
        char prihvatljivost;
        string input;
        is.getline(p, 50);
        input=p;
        if (input.find("Stanje:")==string::npos) {
            cout << "Pogrešan format datoteke!" << endl;
            exit(1);
        }
        stringstream l(input, ios_base::in);
        l.ignore(50, '\t');
        l>>prihvatljivost;
        Stanje si(prihvatljivost=='P', i);
        is.getline(p, 50);
        input=p;
        while (input.find("EndStanje")==string::npos) {
            if (input.find("EPrijelaz")!=string::npos) {
                l.clear();
                l.str(input);
                l.ignore(50, ':');
                char znakStoga;
                l>>znakStoga;
                EPrijelaz noviEPrijelaz(znakStoga);
                is.getline(p, 50);
                input=p;
                while (input.find("EndEPrijelaz")==string::npos) {
                    l.clear();
                    l.str(input);
                    int novoStanje;
                    string znakZaStog;
                    l>>novoStanje>>znakZaStog;
                    noviEPrijelaz.dodajPrijelaz(novoStanje, znakZaStog);
                    is.getline(p, 50);
                    input=p;
                }
                si.dodajEPrijelaz(noviEPrijelaz);
            } else if (input.find("Prijelaz")!=string::npos) {
                l.clear();
                l.str(input);
                l.ignore(50, ':');
                char ulazniZnak, znakStoga;
                l>>ulazniZnak>>znakStoga;
                Prijelaz noviPrijelaz(ulazniZnak, znakStoga);
                is.getline(p, 50);
                input=p;
                while (input.find("EndPrijelaz")==string::npos) {
                    l.clear();
                    l.str(input);
                    int novoStanje;
                    string znakZaStog;
                    l>>novoStanje>>znakZaStog;
                    noviPrijelaz.dodajPrijelaz(novoStanje, znakZaStog);
                    is.getline(p, 50);
                    input=p;
                }
                si.dodajPrijelaz(noviPrijelaz);
            }
            is.getline(p, 50);
            input=p;
        }
        stanja.push_back(si);
    }
    is.close();
    cout << "Automat učitan!" << endl;
    simulate(stanja, pocZnakStoga, epsilon);

    return 0;
}

void simulate(vector<Stanje> &stanja, char pocZnakStoga, char epsilon) {
    char ulaz[50];
    cout << "Unesi ulazni niz: > ";
    cin.getline(ulaz, 50);
    string stog(1, pocZnakStoga);
    list<Konfiguracija> trenutneKonfiguracije1;
    list<Konfiguracija> trenutneKonfiguracije2;
    Konfiguracija prva(stog, stanja[0], ulaz, epsilon);
    trenutneKonfiguracije1.push_back(prva);
    while (trenutneKonfiguracije1.size()>0) {
        trenutneKonfiguracije2.clear();
        for (list<Konfiguracija>::iterator it=trenutneKonfiguracije1.begin(); it!=trenutneKonfiguracije1.end(); it++) {
            list<Konfiguracija> nove=it->obaviPrijelaz(stanja);
            for (list<Konfiguracija>::iterator it2=nove.begin(); it2!=nove.end(); it2++) {
                trenutneKonfiguracije2.push_back(*it2);
            }
        }
        trenutneKonfiguracije1.clear();
        trenutneKonfiguracije1=trenutneKonfiguracije2;
    }
}
