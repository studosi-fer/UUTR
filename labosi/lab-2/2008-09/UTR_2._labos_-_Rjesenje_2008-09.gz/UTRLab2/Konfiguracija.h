#ifndef KONFIGURACIJA_H_INCLUDED
#define KONFIGURACIJA_H_INCLUDED

#include <iostream>
#include <vector>
#include <list>
#include <string>

#include "Stanje.h"
#include "EPrijelaz.h"
#include "Prijelaz.h"

using namespace std;

class Konfiguracija {
private:
    string stog;
    Stanje trenutnoStanje;
    char *neprocitaniDio;
    char epsilon;
    void ispisiStog(bool novo, string noviZnak);
    void ispisiTrenutnoStanje();
    void ispisiPrijelaz(NovoStanje ns, bool epri);
    void ispisiNeprocitano(bool Epr);
public:
    Konfiguracija(string &noviStog, Stanje &novoStanje, char *preostaliUlaz, const char epsilon);
    list<Konfiguracija> obaviPrijelaz(vector<Stanje>& stanja);
    ~Konfiguracija();
};

#endif // KONFIGURACIJA_H_INCLUDED
