#ifndef EPRIJELAZ_H_INCLUDED
#define EPRIJELAZ_H_INCLUDED

#include <list>
#include "novoStanje.h"

using namespace std;

class EPrijelaz {
private:
    char znakStoga;
    list<NovoStanje> prijelazi;
public:
    EPrijelaz(char znakStoga);
    void dodajPrijelaz(int novoStanje, string znakNaStog);
    const list<NovoStanje> getNovaStanja();
    char getZnakStoga();
    bool jesamLiTaj(char znakStoga);
    bool isNull();
};

#endif // EPRIJELAZ_H_INCLUDED
