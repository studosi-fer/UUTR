for i in {1..11}
do
	echo $i;
	java SimTS < primjeri/$i.in > primjeri/tmp;
	diff primjeri/tmp primjeri/$i.out;
done