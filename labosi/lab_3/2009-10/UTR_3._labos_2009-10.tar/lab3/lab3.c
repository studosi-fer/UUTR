/*
 * Treći labos iz UTR-a
 * Simulacija rada Turingovog stroja
 *
 * Ulazi:
 *	- defnicija: u datoteki "definicija"
 *	- početno stanje trake: u datoteki "ulaz"
 *
 * Warning: nepravilna definicija/ulaz može izazvati core dump, krepat s exit(1) ili tak nešt... Ne stavljati prevelike
 * nazive stanja (max 4 znaka) i ne abuseati program :D. Opis formata definicije je negdje u kodu.
 *
 * Rad na npr. pinusu:
 * - skopirati arhivu na pinus (ono čudo *.tar)
 * - $ tar -xf lab3.tar - extracta iz arhive
 * - $ cd lab3
 * - $ vim definicija - zapiše se definiciju unutra
 * - $ vim ulaz - zapiše se početno stanje trake (već ima primjer unutra)
 * - $ make - ovo kompajlira sve
 * - $ ./lab3 - pokreće program
 *
 * Umjesto vi(m) može, naravno, i nano, joe ili bilo koji drugi editor, neznam kojih sve ima na pinusu...
 *
 * HF!
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRAKA 50 /* 50 je više-manje dovoljno za simulaciju nekih manjih umnožaka, a opet lijepo izgleda
			(ne lome se linije na manjim terminalima) */

/* jedan prijelaz */
typedef struct {
	char ime[5]; /* trenutno stanje */
	char ulaz; /* trenutni znak na traki */

	char novo[5]; /* novo stanje */
	char noviZnak; /* novi znak koji će se zapisati na traku */
	char pomakGlave; /* pomak glave: R ili L */
} Prijelaz;

int main(int argc, char *argv[])
{
	Prijelaz *prijelazi = malloc(40 * sizeof(Prijelaz)); /* Pretpostavka: nema više od 40 prijelaza u definiciji, 
								neda mi se slagati linked liste ili kajaznam kaj već */
	/* Traka automata */
	char traka[TRAKA]; /* Pretpostavka: bit će dovoljna duljina trake */
	/* pozicija glave, glava >= 0, ne bi se igral s definicijom koja pomiče glavu lijevo od nultog znaka na traki :D */
	int glava;
	/* broj prijelaza (potrebno za traženje) */
	int kolko;

	/* pomoćne varijable */
	char ime[5], novo[5];
	char ulaz, noviZnak, pomakGlave;
	int i;
	char linija[50];
	FILE *in;

	/* Traka je veličine TRAKA i popunjava se s B-ovima. (recimo da je beskonačno == TRAKA :D) */
	for (i = 0; i < TRAKA; i++) {
		traka[i] = 'B';
	}
	traka[TRAKA - 1] = '\0';

	/* Učita definiciju iz datoteke formata:
	 *	stanje ulazniZnak novoStanje noviZnak pomakGlave
	 *	primjer: "q0 1 q1 B R"
	 * i izbroji kolko ih ima
	 */
	in = fopen("definicija", "r");
	if (in == NULL) {
		exit(1);
	}
	kolko = 0;
	while (fscanf(in, "%s %c %s %c %c", ime, &ulaz, novo, &noviZnak, &pomakGlave) == 5) {
		Prijelaz p;
		strncpy(p.ime, ime, 5);
		p.ime[4] = '\0';
		strncpy(p.novo, novo, 5);
		p.novo[4] = '\0';
		p.ulaz = ulaz;
		p.noviZnak = noviZnak;
		p.pomakGlave = pomakGlave;

		if (kolko == 40) {
			exit(1);
		}
		prijelazi[kolko++] = p;
	}
	fclose(in);

	/* Učita se ulazni niz na traku */
	in = fopen("ulaz", "r");
	if (in == NULL) {
		exit(1);
	}
	fscanf(in, "%s", linija);
	for (i = 0; linija[i] != '\0' && i != 50 && i != TRAKA - 1; i++) {
		traka[i] = linija[i];
	}
	fclose(in);

	/* Simuliranje rada stroja */
	/* Postavi se glava i početno stanje (q0 mora biti početno u definiciji automata) */
	strcpy(ime, "q0");
	glava = 0;
	while (1) {
		Prijelaz nadjeno;
		int nasao = 0;

		printf("Stanje: %s\n", ime);
		printf("%s\n", traka);
		for (i = 0; i < glava; i++) {
			printf(" ");
		}
		printf("^\n\n");

		ulaz = traka[glava];
		/* Pronađi prijelaz */
		for (i = 0; i < kolko; i++) {
			Prijelaz p = prijelazi[i];
			if (!strcmp(p.ime, ime) && p.ulaz == ulaz) {
				nadjeno = p;
				nasao = 1;
				break;
			}
		}
		/* Nije našao prijelaz, znači da nije definiran -> automat staje */
		if (nasao == 0) {
			printf("Zavrseno\n");
			break;
		}

		/* postavi novo nađeno stanje kao trenutno, zapiši novi znak i pomakni glavu po potrebi */
		strcpy(ime, nadjeno.novo);
		traka[glava] = nadjeno.noviZnak;
		if (nadjeno.pomakGlave == 'R') {
			glava++;
		} else {
			glava--;
		}
	}

	free(prijelazi);

	return 0;
}
