import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

public class MinDka {
	private static String pocetnoStanje;
	private static TreeSet<String> skupStanja;
	private static TreeSet<String> skupSimbolaAbecede;
	private static TreeSet<String> prihvatljivaStanja;
	private static LinkedHashMap<String, String> prijelazi;
	private static LinkedHashMap<String, String> ispisMapa = new LinkedHashMap<String, String>();
	private static TreeSet<String> dohvatljivaStanja;
	private static LinkedHashMap<String, String> stanjaX = new LinkedHashMap<String, String>();
	private static LinkedHashMap<String, String> mapaCekanja = new LinkedHashMap<String, String>();

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		int i = 0;
		String line;
		prijelazi = new LinkedHashMap<String, String>();
		int brojac = 0;
		while ((line = reader.readLine()) != null && brojac != 2) {
			switch (i) {
			case 0:
				String[] firstline = line.split(",");
				skupStanja = new TreeSet<String>();
				for (int j = 0; j < firstline.length; j++) {
					skupStanja.add(firstline[j]);
				}
				i++;
				break;
			case 1:
				String[] secondLine = line.split(",");
				skupSimbolaAbecede = new TreeSet<String>();
				for (int j = 0; j < secondLine.length; j++) {
					skupSimbolaAbecede.add(secondLine[j]);
				}
				i++;
				break;
			case 2:
				prihvatljivaStanja = new TreeSet<String>();
				if (!line.isEmpty()) {
					String[] thirdLine = line.split(",");

					for (int j = 0; j < thirdLine.length; j++) {
						prihvatljivaStanja.add(thirdLine[j]);
					}
				} else {
					brojac++;
				}

				i++;
				break;
			case 3:
				pocetnoStanje = line;
				i++;
				break;
			default:
				if (line.isEmpty()) {
					brojac++;
				} else {
					prijelazi.put(line.split("->")[0], line.split("->")[1]);
				}
				break;
			}

		}
		izracunajDohvatljivaStanja();
		minimizirajDKA();
		ispisSeta(skupStanja);
		ispisSeta(skupSimbolaAbecede);
		ispisSeta(prihvatljivaStanja);
		ispisPocetnogStanja();
		ispisiStanja(ispisMapa);

	}

	private static void ispisPocetnogStanja() {
		System.out.println(pocetnoStanje);

	}

	/**
	 * Metoda koja u prijelazi ostavi samo dohvatljiva stanja izracunata na
	 * temelju pocetnog stanja te prijelaza
	 */
	private static void izracunajDohvatljivaStanja() {
		List<String> dohvatljiva = new ArrayList<String>();
		dohvatljiva.add(pocetnoStanje);
		LinkedHashMap<String, String> pomocna = new LinkedHashMap<String, String>();
		for (int i = 0; i < dohvatljiva.size(); i++) {
			for (String temp : prijelazi.keySet()) {
				if (temp.split(",")[0].equals(dohvatljiva.get(i))) {
					if (!dohvatljiva.contains(prijelazi.get(temp))) {
						dohvatljiva.add(prijelazi.get(temp));
					}

				}
			}
		}
		dohvatljivaStanja = new TreeSet<String>();
		dohvatljivaStanja.addAll(dohvatljiva);
		for (String temp : prijelazi.keySet()) {
			if (dohvatljivaStanja.contains(temp.split(",")[0])) {
				pomocna.put(temp, prijelazi.get(temp));
			}
		}
		prijelazi.clear();
		prijelazi = pomocna;
		skupStanja.clear();
		skupStanja = dohvatljivaStanja;
		TreeSet<String> pomocniSet = new TreeSet<String>();
		pomocniSet.addAll(prihvatljivaStanja);
		prihvatljivaStanja.clear();
		for (String temp : dohvatljivaStanja) {
			if (pomocniSet.contains(temp)) {
				prihvatljivaStanja.add(temp);
			}
		}

	}

	/**
	 * Metoda koja stvara mapu za ispis...
	 */
	private static void minimizirajDKA() {
		ArrayList<String> listaStanja = new ArrayList<String>();
		listaStanja.addAll(skupStanja);
		for (int i = 0; i < skupStanja.size() - 1; i++) {// ide po stupcima
			for (int j = i + 1; j < skupStanja.size(); j++) {// ide po redovima
				if (prihvatljivaStanja.contains(listaStanja.get(i))
						^ prihvatljivaStanja.contains(listaStanja.get(j))) {

					String kljuc = listaStanja.get(i) + ","
							+ listaStanja.get(j);
					stanjaX.put(kljuc, "X");
				}

			}
		}
		for (int i = 0; i < skupStanja.size() - 1; i++) {
			for (int j = i + 1; j < skupStanja.size(); j++) {
				for (String prijelaz : skupSimbolaAbecede) {
					String prvi = listaStanja.get(i) + "," + prijelaz;
					String drugi = listaStanja.get(j) + "," + prijelaz;
					String stanje1 = prijelazi.get(prvi);
					String stanje2 = prijelazi.get(drugi);
					if (stanje1.compareTo(stanje2) > 0) {
						String tmp;
						tmp = stanje1;
						stanje1 = stanje2;
						stanje2 = tmp;
					}
					String kljuc = stanje1 + "," + stanje2;
					if (stanjaX.containsKey(kljuc)) {
						stanjaX.put(
								listaStanja.get(i) + "," + listaStanja.get(j),
								"X");
					} else {
						mapaCekanja.put(kljuc, listaStanja.get(i) + ","
								+ listaStanja.get(j));
					}
				}
			}
		}
		int promijenjen = 0;

		while (true) {

			for (String stanja : mapaCekanja.keySet()) {
				if (stanjaX.containsKey(stanja)) {
					stanjaX.put(mapaCekanja.get(stanja), "X");
					promijenjen++;
				}
			}
			if (promijenjen > mapaCekanja.size() * 4 || promijenjen == 0) {
				break;
			}
		}

		TreeSet<String> mogucnosti = vratiSveMogucnosti();
		TreeSet<String> istaStanja = new TreeSet<String>();
		for (String mogucnost : mogucnosti) {
			if (!stanjaX.containsKey(mogucnost)) {
				istaStanja.add(mogucnost);
			}
		}
		ispisMapa = prijelazi;
		ukloniIstaStanja(ispisMapa, istaStanja);
	}

	private static void ukloniIstaStanja(LinkedHashMap<String, String> mapa,
			TreeSet<String> istaStanja) {

		for (String stanje : istaStanja) {
			for (String prijelaz : skupSimbolaAbecede) {
				String ukloni = stanje.split(",")[1] + "," + prijelaz;
				mapa.remove(ukloni);
				skupStanja.remove(stanje.split(",")[1]);
				skupSimbolaAbecede.remove(stanje.split(",")[1]);
				prihvatljivaStanja.remove(stanje.split(",")[1]);
				if (stanje.split(",")[1].equals(pocetnoStanje)) {
					pocetnoStanje = stanje.split(",")[0];
				}

			}
		}

		for (String stanje : mapa.keySet()) {
			for (String ista : istaStanja) {
				if (mapa.get(stanje).equals(ista.split(",")[1])) {
					mapa.put(stanje, ista.split(",")[0]);
				}
			}
		}

	}

	private static void ispisiStanja(Map<String, String> mapa) {
		for (String temp : mapa.keySet()) {
			System.out.println(temp + "->" + mapa.get(temp));
		}
	}

	private static void ispisSeta(TreeSet<String> set) {
		for (String tmp : set) {
			if (tmp.equals(set.last())) {
				System.out.println(tmp);
			} else {
				System.out.print(tmp + ",");
			}
		}
		if (set.size() == 0) {
			System.out.println();
		}
	}

	private static TreeSet<String> vratiSveMogucnosti() {
		TreeSet<String> mogucnosti = new TreeSet<String>();
		ArrayList<String> listaStanja = new ArrayList<String>();
		listaStanja.addAll(skupStanja);
		for (int i = 0; i < skupStanja.size() - 1; i++) {// ide po stupcima
			for (int j = i + 1; j < skupStanja.size(); j++) {// ide po redovima
				mogucnosti.add(listaStanja.get(i) + "," + listaStanja.get(j));
			}
		}
		return mogucnosti;
	}
}