import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.TreeSet;

/**
 * Simulator Turingova Stroja
 * 
 * @version 1.0
 * @since 03.05.2014
 */
public class SimTS {
	@SuppressWarnings("unused")
	private static String znakPrazneCelije;
	private static ArrayList<String> skupUlaznihZnakova;
	private static TreeSet<String> skupStanja;
	private static TreeSet<String> skupZnakovaTrake;
	private static TreeSet<String> skupPrihvatljivihStanja;
	private static LinkedHashMap<String, String> funkcijePrijelaza;
	private static char[] zapisTrakeTS;
	private static String pocetnoStanje;
	private static Integer pocetniPolozajGlave;
	private static String trenutnoStanje;
	private static Integer trenutniPolozajGLave;
	private static String txtPrikazTrake;
	private static Integer prihvatljivostNiza;

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		int i = 1;
		int brojac = 0;
		String line;
		funkcijePrijelaza = new LinkedHashMap<String, String>();
		while ((line = reader.readLine()) != null && brojac != 2) {
			switch (i) {
			case 1:
				String[] firstLine = line.split(",");
				skupStanja = new TreeSet<String>();
				for (int j = 0; j < firstLine.length; j++) {
					skupStanja.add(firstLine[j]);
				}
				i++;
				break;
			case 2:
				String[] secondLine = line.split(",");
				skupUlaznihZnakova = new ArrayList<String>();
				for (int j = 0; j < secondLine.length; j++) {
					skupUlaznihZnakova.add(secondLine[j]);
				}
				i++;
				break;
			case 3:
				String[] thirdLine = line.split(",");
				skupZnakovaTrake = new TreeSet<String>();
				for (int j = 0; j < thirdLine.length; j++) {
					skupZnakovaTrake.add(thirdLine[j]);
				}
				i++;
				break;
			case 4:
				znakPrazneCelije = line;
				i++;
				break;
			case 5:
				zapisTrakeTS = line.toCharArray();
				i++;
				break;
			case 6:
				skupPrihvatljivihStanja = new TreeSet<String>();
				if (!line.isEmpty()) {
					String[] sixthLine = line.split(",");
					for (int j = 0; j < sixthLine.length; j++) {
						skupPrihvatljivihStanja.add(sixthLine[j]);
					}
				} else {
					brojac++;
				}
				i++;
				break;
			case 7:
				pocetnoStanje = line;
				i++;
				break;
			case 8:
				pocetniPolozajGlave = Integer.parseInt(line);
				i++;
				break;
			default:
				if (line.isEmpty()) {
					brojac++;
				} else {
					funkcijePrijelaza.put(line.split("->")[0],
							line.split("->")[1]);
				}
				break;
			}
		}
		SimulirajTuringovStroj();
	}

	/**
	 * Metoda koja simulira Turingov Stroj
	 */
	private static void SimulirajTuringovStroj() {
		trenutnoStanje = pocetnoStanje;
		trenutniPolozajGLave = pocetniPolozajGlave;
		boolean dokImaPrijelaza = true;
		while (dokImaPrijelaza) {
			String kljuc = trenutnoStanje + ","
					+ zapisTrakeTS[trenutniPolozajGLave];
			if (funkcijePrijelaza.get(kljuc) == null) {
				break;
			} else {
				String prijelaz = funkcijePrijelaza.get(kljuc);
				trenutnoStanje = prijelaz.split(",")[0];
				zapisTrakeTS[trenutniPolozajGLave] = prijelaz.split(",")[1]
						.toCharArray()[0];
				if (trenutniPolozajGLave == 0
						&& prijelaz.split(",")[2].equals("L")) {
					trenutniPolozajGLave = 0;
					break;
				}
				if (trenutniPolozajGLave == 69
						&& prijelaz.split(",")[2].equals("R")) {
					trenutniPolozajGLave = 69;
					break;
				}
				if (prijelaz.split(",")[2].equals("R")) {
					trenutniPolozajGLave++;
				} else {
					trenutniPolozajGLave--;
				}
			}
		}
		StringBuilder zapis = new StringBuilder();
		for (char temp : zapisTrakeTS) {
			zapis.append(temp);
		}
		txtPrikazTrake = zapis.toString();
		if (skupPrihvatljivihStanja.contains(trenutnoStanje)) {
			prihvatljivostNiza = 1;
		} else {
			prihvatljivostNiza = 0;
		}
		ispisTS();
	}
/**
 * metoda koja ispisuje Turingov Stroj
 */
	public static void ispisTS() {
		System.out.println(trenutnoStanje + "|" + trenutniPolozajGLave + "|"
				+ txtPrikazTrake + "|" + prihvatljivostNiza);
	}
}
