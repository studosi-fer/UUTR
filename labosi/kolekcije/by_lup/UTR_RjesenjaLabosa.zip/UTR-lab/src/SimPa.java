import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Stack;
import java.util.TreeSet;

public class SimPa {
	private static ArrayList<String> ulazniNizovi;
	private static TreeSet<String> skupStanja;
	private static TreeSet<String> skupUlaznihZnakova;
	private static TreeSet<String> skupZnakovaStoga;
	private static TreeSet<String> prihvatljivaStanja;
	private static String pocetnoStanje;
	private static char pocetniZnakStoga;
	private static LinkedHashMap<String, String> funkcijePrijelaza;
	private static Stack<Character> stog = new Stack<Character>();
	private static String trenutnoStanje;
	private static char trenutniZnakStoga;

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		int i = 1;
		int brojac = 0;
		String line;
		funkcijePrijelaza = new LinkedHashMap<String, String>();
		while ((line = reader.readLine()) != null && brojac != 2) {
			switch (i) {
			case 1:
				String[] firstLine = line.split("\\|");
				ulazniNizovi = new ArrayList<String>();
				for (int j = 0; j < firstLine.length; j++) {
					ulazniNizovi.add(firstLine[j]);
				}
				i++;
				break;
			case 2:
				String[] secondLine = line.split(",");
				skupStanja = new TreeSet<String>();
				for (int j = 0; j < secondLine.length; j++) {
					skupStanja.add(secondLine[j]);
				}
				i++;
				break;
			case 3:
				String[] thirdLine = line.split(",");
				skupUlaznihZnakova = new TreeSet<String>();
				for (int j = 0; j < thirdLine.length; j++) {
					skupUlaznihZnakova.add(thirdLine[j]);
				}
				i++;
				break;
			case 4:
				String[] fourthLine = line.split(",");
				skupZnakovaStoga = new TreeSet<String>();
				for (int j = 0; j < fourthLine.length; j++) {
					skupZnakovaStoga.add(fourthLine[j]);
				}
				i++;
				break;
			case 5:
				prihvatljivaStanja = new TreeSet<String>();
				if (!line.isEmpty()) {
					String[] fifthLine = line.split(",");
					for (int j = 0; j < fifthLine.length; j++) {
						prihvatljivaStanja.add(fifthLine[j]);
					}
				} else {
					brojac++;
				}
				i++;
				break;
			case 6:
				pocetnoStanje = line;
				i++;
				break;
			case 7:
				pocetniZnakStoga = line.toCharArray()[0];
				i++;
				break;
			default:
				if (line.isEmpty()) {
					brojac++;
				} else {
					funkcijePrijelaza.put(line.split("->")[0],
							line.split("->")[1]);
				}
				break;
			}

		}

		for (String temp : ulazniNizovi) {
			izvrsiAutomat(temp);
		}

	}

	private static void izvrsiAutomat(String temp) {
		boolean uvjet = false;
		String[] ulaznaStanja = temp.split(",");
		dodajPocetniNaStog();
		trenutniZnakStoga = pocetniZnakStoga;
		trenutnoStanje = pocetnoStanje;
		System.out.print(trenutnoStanje + "#" + trenutniZnakStoga + "|");
		for (int i = 0; i < ulaznaStanja.length;) {
			String kljuc = trenutnoStanje + "," + ulaznaStanja[i] + ","
					+ trenutniZnakStoga;
			String kljuc2 = trenutnoStanje + ",$," + trenutniZnakStoga;
			if (funkcijePrijelaza.containsKey(kljuc)) {
				String prijelaz = funkcijePrijelaza.get(kljuc);
				trenutnoStanje = prijelaz.split(",")[0];
				char[] polje = prebaciStringUObrnutiChar(prijelaz.split(",")[1]);
				izmjeniStanjeNaStogu(polje);
				System.out.print(trenutnoStanje + "#");
				ispisiStog();
				trenutniZnakStoga = stog.peek();
				i++;
			} else if (funkcijePrijelaza.containsKey(kljuc2)) {
				String prijelaz = funkcijePrijelaza.get(kljuc2);
				trenutnoStanje = prijelaz.split(",")[0];
				char[] polje = prebaciStringUObrnutiChar(prijelaz.split(",")[1]);
				izmjeniStanjeNaStogu(polje);
				System.out.print(trenutnoStanje + "#");
				trenutniZnakStoga = stog.peek();
				ispisiStog();
			} else {
				System.out.println("fail|0");
				uvjet = true;
				break;
			}
		}

		boolean uvjet2 = true;
		if(prihvatljivaStanja.contains(trenutnoStanje)){
			uvjet2=false;
		}
		while (uvjet2) {
			uvjet2 = provjeriEpsilonPrijelaz(trenutnoStanje, trenutniZnakStoga);
			if(prihvatljivaStanja.contains(trenutnoStanje)){
				uvjet2=false;
			}
		}

		if (uvjet) {
			uvjet = false;
		} else {
			if (prihvatljivaStanja.contains(trenutnoStanje)) {
				System.out.println("1");
			} else {
				System.out.println("0");
			}
		}
		stog.clear();

	}

	private static boolean provjeriEpsilonPrijelaz(String stanje, char Znak) {
		boolean izmijenjen = false;
		String kljuc = stanje + ",$," + Znak;
		if (funkcijePrijelaza.containsKey(kljuc)) {
			String prijelaz = funkcijePrijelaza.get(kljuc);
			trenutnoStanje = prijelaz.split(",")[0];
			char[] polje = prebaciStringUObrnutiChar(prijelaz.split(",")[1]);
			izmjeniStanjeNaStogu(polje);
			System.out.print(trenutnoStanje + "#");
			trenutniZnakStoga = stog.peek();
			ispisiStog();
			izmijenjen = true;
		}
		return izmijenjen;
	}

	private static void ispisiStog() {
		if (stog.isEmpty()) {
			System.out.print("$");
		} else {
			char[] polje = new char[stog.size() + 1];
			int i = stog.size();
			for (char znak : stog) {
				polje[i] = znak;
				i--;
			}
			for (int j = 1; j < polje.length; j++) {
				System.out.print(polje[j]);
			}
		}
		System.out.print("|");
	}

	private static char[] prebaciStringUObrnutiChar(String string) {
		String obrnuti = new StringBuilder(string).reverse().toString();
		char[] poljechar = obrnuti.toCharArray();
		return poljechar;
	}

	private static void dodajPocetniNaStog() {
		stog.add(pocetniZnakStoga);
	}

	private static void izmjeniStanjeNaStogu(char[] znakovi) {
		if (!stog.isEmpty()) {
			stog.pop();
		}
		for (char temp : znakovi) {
			stog.push(temp);
		}
		if(znakovi[0]=='$'){
			stog.pop();
		}
		if(stog.isEmpty()){
			stog.push('$');
		}
	}

}
