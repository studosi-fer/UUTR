import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Parser rekurzivnim spustom
 * 
 * @version 1.0
 * @since 15.05.2014
 */
public class Parser {
	private static ArrayList<Character> testPodatci = new ArrayList<Character>();
	private static String ulaznaLinija;
	private static ArrayList<Character> ispis = new ArrayList<Character>();

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		ulaznaLinija = reader.readLine();
		for (int i = 0; i < ulaznaLinija.length(); i++) {
			char c = ulaznaLinija.charAt(i);
			testPodatci.add(c);
		}
		boolean sveURedu = potprogramZaParsiranje('S');
		for (char znak : ispis) {
			System.out.print(znak);
		}
		System.out.println();

		if (sveURedu && (testPodatci.size() == 0)) {
			System.out.println("DA");
		} else {
			System.out.println("NE");
		}
	}

	private static boolean potprogramZaParsiranje(char znakAbecede) {
		boolean valjan = false;

		switch (znakAbecede) {
		/**
		 * Dio koji provjerava jel S->aAB|bBA
		 * 
		 */
		case 'S':
			ispis.add('S');
			if (testPodatci.size() == 0) {
				return false;
			} else {
				if (testPodatci.get(0).equals('b')) {
					testPodatci.remove(0);
					valjan = potprogramZaParsiranje('B');
					if (valjan) {
						valjan = potprogramZaParsiranje('A');
					}
					return valjan;
				}
			}
			if (testPodatci.size() == 0) {
				return false;
			} else {
				if (testPodatci.get(0).equals('a')) {
					testPodatci.remove(0);
					valjan = potprogramZaParsiranje('A');
					if (valjan) {
						valjan = potprogramZaParsiranje('B');
					}
				}
			}
			break;
		/**
		 * Dio koji provjerava jel A->bC|a
		 * 
		 */
		case 'A':
			ispis.add('A');

			if (testPodatci.size() == 0) {
				return false;
			} else {
				if (testPodatci.get(0).equals('b')) {
					testPodatci.remove(0);
					valjan = potprogramZaParsiranje('C');
					return valjan;
				}
			}
			if (testPodatci.size() == 0) {
				return false;
			} else {
				if (testPodatci.get(0).equals('a')) {
					testPodatci.remove(0);
					valjan = true;
				}
			}
			break;
		/**
		 * Dio koji provjerava jel B->ccSbc|epsilon
		 * 
		 */
		case 'B':
			ispis.add('B');
			if (testPodatci.size() == 0) {
				valjan = true;
			} else {
				valjan = false;
				if (testPodatci.get(0).equals('c')) {
					testPodatci.remove(0);
					if (testPodatci.size() != 0
							&& testPodatci.get(0).equals('c')) {
						testPodatci.remove(0);
						boolean medukorak = potprogramZaParsiranje('S');
						if (medukorak && testPodatci.size() != 0
								&& testPodatci.get(0).equals('b')) {
							testPodatci.remove(0);
							if (testPodatci.size() != 0
									&& testPodatci.get(0).equals('c')) {
								testPodatci.remove(0);
								valjan = true;

							} else {

								valjan = false;
							}
						} else {
							valjan = false;
						}
					} else {
						valjan = false;
					}
				} else {
					valjan = true;
				}
			}
			break;
		/**
		 * Dio koji provjerava jel C->AA
		 * 
		 * @return true ako je valjan,inace false
		 */
		case 'C':
			ispis.add('C');
			valjan = potprogramZaParsiranje('A');
			if (valjan)
				valjan = potprogramZaParsiranje('A');
			break;
		/**
		 * Dio koji se nikad nebi trebao dogoditi
		 */
		default:
			System.out.println("Nesto je poslo po krivu");
			break;
		}
		return valjan;
	}
}
