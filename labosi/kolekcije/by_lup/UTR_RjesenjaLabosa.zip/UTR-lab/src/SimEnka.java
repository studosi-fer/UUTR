import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.TreeSet;

public class SimEnka {
	private static String pocetnoStanje;
	private static ArrayList<String> ulazniNizovi;
	private static TreeSet<String> skupStanja;
	private static TreeSet<String> skupSimbolaAbecede;
	private static TreeSet<String> prihvatljivaStanja;
	private static LinkedHashMap<String, String> prijelazi;

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				System.in));
		int i = 0;
		String line;
		prijelazi = new LinkedHashMap<String, String>();
		while ((line = reader.readLine()) != null && !(line.isEmpty())) {
			switch (i) {
			case 0:
				String[] firstLine = line.split("\\|");
				ulazniNizovi = new ArrayList<String>();
				for (int j = 0; j < firstLine.length; j++) {
					ulazniNizovi.add(firstLine[j]);
				}
				i++;
				break;
			case 1:
				String[] secondLine = line.split(",");
				skupStanja = new TreeSet<String>();
				for (int j = 0; j < secondLine.length; j++) {
					skupStanja.add(secondLine[j]);
				}
				i++;
				break;
			case 2:
				String[] thirdLine = line.split(",");
				skupSimbolaAbecede = new TreeSet<String>();
				for (int j = 0; j < thirdLine.length; j++) {
					skupSimbolaAbecede.add(thirdLine[j]);
				}
				i++;
				break;
			case 3:
				String[] fourthLine = line.split(",");
				prihvatljivaStanja = new TreeSet<String>();
				for (int j = 0; j < fourthLine.length; j++) {
					prihvatljivaStanja.add(fourthLine[j]);
				}
				i++;
				break;
			case 4:
				pocetnoStanje = line;
				i++;
				break;
			default:
				prijelazi.put(line.split("->")[0], line.split("->")[1]);
				break;
			}
		}
		for (String temp : ulazniNizovi) {
			executeAutomat(temp);
		}
	}

	private static void executeAutomat(String ulazniNiz) {
		String[] ulaznaStanja = ulazniNiz.split(",");
		TreeSet<String> sviPrijelazi = new TreeSet<String>();
		TreeSet<String> trenutnaStanja = new TreeSet<String>();
		TreeSet<String> povratnaEpsilon = new TreeSet<String>();
		TreeSet<String> povratnaPrijelaz = new TreeSet<String>();

		trenutnaStanja.add(pocetnoStanje);
		sviPrijelazi.addAll(trenutnaStanja);

		int prosliPovratak = 0;
		while (true) {
			povratnaEpsilon = executeEpsilon(sviPrijelazi);
			if (povratnaEpsilon.size() == 0) {
				break;
			}
			if (povratnaEpsilon.size() == prosliPovratak) {
				break;
			}
			prosliPovratak = povratnaEpsilon.size();
			sviPrijelazi.addAll(povratnaEpsilon);
		}
		trenutnaStanja.addAll(povratnaEpsilon);
		trenutnaStanja.addAll(sviPrijelazi);
		ispisStanja(sviPrijelazi);
		System.out.print("|");

		for (int i = 0; i < ulaznaStanja.length; i++) {
			sviPrijelazi.removeAll(sviPrijelazi);
			povratnaPrijelaz = executePrijelaz(trenutnaStanja, ulaznaStanja[i]);
			sviPrijelazi.addAll(povratnaPrijelaz);
			prosliPovratak = 0;
			if (povratnaPrijelaz.size() != 0) {
				while (true) {
					povratnaEpsilon = executeEpsilon(sviPrijelazi);
					if (povratnaEpsilon.size() == 0) {
						break;
					}

					if (povratnaEpsilon.size() == prosliPovratak) {
						break;
					}
					prosliPovratak = povratnaEpsilon.size();
					sviPrijelazi.addAll(povratnaEpsilon);

				}

				if (sviPrijelazi.contains("#") && sviPrijelazi.size() != 1) {
					sviPrijelazi.remove("#");
				}
				ispisStanja(sviPrijelazi);
				if (i != ulaznaStanja.length - 1) {
					System.out.print("|");
				}

				trenutnaStanja.removeAll(trenutnaStanja);
				trenutnaStanja.addAll(sviPrijelazi);

			} else {
				trenutnaStanja.removeAll(trenutnaStanja);
				trenutnaStanja.add("#");
				System.out.print("|#");
			}

		}
		System.out.println();
	}

	private static TreeSet<String> executePrijelaz(
			TreeSet<String> trenutnaStanja, String ulaznoStanje) {

		TreeSet<String> povratniLHS = new TreeSet<String>();
		for (int i = 0; i < trenutnaStanja.size(); i++) {
			String prijelaz = trenutnaStanja.toArray()[i].toString()
					.concat(",").concat(ulaznoStanje);
			if (prijelazi.containsKey(prijelaz)) {
				String novaStanja = prijelazi.get(prijelaz);
				for (int j = 0; j < novaStanja.split(",").length; j++) {
					povratniLHS.add(novaStanja.split(",")[j]);
				}
			} else {
				povratniLHS.add("#");
			}
		}
		return povratniLHS;
	}

	private static void ispisStanja(TreeSet<String> trenutnaStanja) {
		for (int i = 0; i < trenutnaStanja.size(); i++) {
			System.out.print(trenutnaStanja.toArray()[i]);
			if (i != trenutnaStanja.size() - 1) {
				System.out.print(",");
			}
		}
	}

	private static TreeSet<String> executeEpsilon(TreeSet<String> trenutnaStanja) {
		TreeSet<String> povratniLHS = new TreeSet<String>();
		for (int i = 0; i < trenutnaStanja.size(); i++) {
			String prijelaz = trenutnaStanja.toArray()[i].toString().concat(
					",$");
			if (prijelazi.containsKey(prijelaz)) {
				String novaStanja = prijelazi.get(prijelaz);

				for (int j = 0; j < novaStanja.split(",").length; j++) {
					povratniLHS.add(novaStanja.split(",")[j]);
				}
			}
		}
		return povratniLHS;
	}
}