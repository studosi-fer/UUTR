import sys

def CheckExit(newState, newSymbol, move, head):
    if ( newState, newSymbol, move ) == (False, False, False):
        return True

    if( head == 0 and move == 'L' ) or ( head == 69 and move == 'R'):
        return True

    return False


states = sys.stdin.readline().replace('\n','').split(',')
symbols = sys.stdin.readline().replace('\n','').split(',')
tapeSymbols = sys.stdin.readline().replace('\n','').split(',')
emptyCell = sys.stdin.readline().replace('\n','').split(',')[0]
tape = list(sys.stdin.readline().replace('\n',''))
acceptable = sys.stdin.readline().replace('\n','').split(',')
state = sys.stdin.readline().replace('\n','').split(',')[0]
head = int(sys.stdin.readline().replace('\n','').split(',')[0])

grammar = {}
line = sys.stdin.readline().replace('\n','')
while line != '':
    grammar[tuple(line.split("->")[0].split(','))] = tuple(line.split("->")[1].split(','))
    line = sys.stdin.readline().replace('\n','')

exitFlag = 0
while exitFlag == 0:
    (newState, newSymbol, move) = grammar.get((state, tape[head]), (False, False, False))

    if CheckExit( newState, newSymbol, move, head ):
        exitFlag = 1
        break

    state = newState
    tape[head] = newSymbol
    if move == 'L':
        head = head - 1
    elif move == 'R':
        head = head + 1

output = ""
output += state + "|"
output += str(head) + "|"
for s in tape:
    output += s
output += "|"
if state in acceptable:
    output += "1"
else:
    output += "0"

print output

    
