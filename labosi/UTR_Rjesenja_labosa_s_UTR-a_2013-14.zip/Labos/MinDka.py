import sys

states = sys.stdin.readline().replace('\n','').split(',')
symbols = sys.stdin.readline().replace('\n','').split(',')
acceptable = sys.stdin.readline().replace('\n','').split(',')
start = sys.stdin.readline().replace('\n','').split(',')[0]

grammar = {}
line = sys.stdin.readline().replace('\n','')
while line != '':
    grammar[line.split("->")[0]] = line.split("->")[1]
    line = sys.stdin.readline().replace('\n','')


tempStates = []
tempStates.append(start)
reachable = []
while True:
    if not tempStates:
        break
    newStates = []
    for state in tempStates:
        if state not in reachable:
            reachable.append(state)
            nextStates = []
            for symbol in symbols:
                key = ""
                key += state + ',' + symbol
                if key in grammar:
                    nextStates.append(grammar[key])
            
            toAdd = [s for s in nextStates if s not in newStates]
            newStates.extend(toAdd)
    tempStates = [s for s in newStates]

states = [s for s in reachable]
tempStates = [s for s in reachable if s in acceptable]
acceptable = [s for s in tempStates]

groups = []
g1 = []
g2 = []

for s in states:
    if s in acceptable:
        g1 += [s]
    else:
        g2 += [s]

g1.sort()
g2.sort()
groups += [g1]
groups += [g2]

i = 1
while i:
    i = 0
    newGroups = []
    for g in groups:
        if len(g) == 0:
            continue
        g1 = []
        g2 = []
        g1 += [g[0]]
        if len(g) == 1:
            newGroups += [g1]
            continue
        tempState = g[0]
        for state in g:
            if state != tempState:
                notSame = 0
                for symbol in symbols:
                    trans1 = grammar[tempState + ',' + symbol]
                    trans2 = grammar[state + ',' + symbol]
                    for group in groups:
                        if trans1 in group:
                            if trans2 not in group:
                                notSame = 1
                                break

                if notSame:
                    g2 += [state]
                    g2.sort()
                    
                else:
                    g1 += [state]
                    g1.sort()
        
        newGroups += [g1]
        if len(g2) > 0:
            i += 1
            newGroups += [g2]

    groups = [group for group in newGroups]

states = [s[0] for s in groups]
states.sort()
print ','.join(map( str, states ))

print ','.join(map( str, symbols ))

acc = []
for s in acceptable:
    for g in groups:
        if s in g:
            if g[0] not in acc:
                acc += [g[0]]

acc.sort()
print ','.join(map( str, acc ))

for g in groups:
    if start in g:
        start = g[0]
        break
print start

for state in states:
    for symbol in symbols:
        nextState = grammar[state + ',' + symbol]
 
        for g in groups:
            if state in g:
                newState = g[0]
            if nextState in g:
                nextState = g[0]

        print newState + ',' + symbol + '->' + nextState
        
