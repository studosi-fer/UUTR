# -*- coding: utf-8 -*-

definicija = open("definicija.txt", "r").read().split()

stanja = definicija[0].split(',')
abeceda = definicija[1].split(',')
prihvatljiva = definicija[2].split(',')
prijelazi = []

def epsilon_korak(stanja, prijelazi):
    nova_stanja = stanja
    for p in prijelazi:
        if p[1] == '$' and p[0] in stanja:
            nova_stanja = nova_stanja.union(p[2:])

    if nova_stanja == stanja: return nova_stanja
    else: return epsilon_korak(nova_stanja, prijelazi)

for p in definicija[4:]:
    par = p.split('->')
    lijevo = par[0].split(',')
    desno  = par[1].split(',')
    prijelazi += [lijevo + desno]

pocetna = epsilon_korak(set(definicija[3].split(',')), prijelazi)

nizovi = open("ulazni_znakovi.txt", "r").read()
nizovi = nizovi.replace('\r', '').split('\n')[:-1]

for niz in nizovi:
    trenutna_stanja = pocetna

    print
    print "Niz", '"'+niz+'":'
    print " ->", ', '.join(trenutna_stanja)

    for z in niz:
        iduca_stanja = set()
        for stanje in trenutna_stanja:
            for p in prijelazi:
                if p[0] in trenutna_stanja and p[1] == z:
                    iduca_stanja = iduca_stanja.union(p[2:])
                    iduca_stanja = epsilon_korak(iduca_stanja, prijelazi)

        trenutna_stanja = iduca_stanja
        print ' '+z+':', ', '.join(trenutna_stanja)

    if [a for a in trenutna_stanja if a in prihvatljiva]:
        print "Niz prihvaćen."
    else:
        print "Niz NIJE prihvaćen."
