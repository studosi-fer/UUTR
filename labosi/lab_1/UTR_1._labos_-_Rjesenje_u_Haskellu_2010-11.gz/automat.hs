import Data.List (foldl', nub, intercalate, intersect)
import Data.List.Split (splitOn)
import Control.Monad (forM_)

type Stanje = String
data Prijelaz = P { zaStanje :: Stanje, zaZnak :: Char, onda :: [Stanje] }

main = do
  definicija <- lines `fmap` readFile "definicija.txt"
  nizovi <- lines `fmap` readFile "ulazni_znakovi.txt"
  forM_ nizovi $ \niz ->
    let (prvi:koraci, prihvaćeno) = simuliraj definicija niz
        pretty znak stanja = ' ':znak:": " ++ intercalate ", " stanja
    in  mapM_ putStrLn $ concat
          ["\nNiz ", show niz, if prihvaćeno then " je" else " NIJE",
           " prihvaćen:\n -> ", intercalate ", " prvi]
          : zipWith pretty niz koraci

prijelaz :: String -> Prijelaz
prijelaz linija = P trenutno (head znak) iduća where
  [[trenutno, znak], iduća] = map (splitOn ",") $ splitOn "->" linija

simuliraj definicija niz = (reverse koraci, ok) where
  početna = saEpsilonima prijelazi . splitOn "," $ definicija !! 3
  prijelazi = map prijelaz $ drop 4 definicija
  koraci = foldl' (korak prijelazi) [početna] niz
  ok = not.null $ intersect (splitOn "," $ definicija !! 2) (head koraci)

korak :: [Prijelaz] -> [[Stanje]] -> Char -> [[Stanje]]
korak ps povijest@(sad:_) znak = iduća : povijest where
  direktni = filter (\p -> zaZnak p == znak && zaStanje p `elem` sad) ps
  iduća = saEpsilonima ps $ concatMap onda direktni

saEpsilonima :: [Prijelaz] -> [Stanje] -> [Stanje]
saEpsilonima ps ss = if nova == ss then ss else saEpsilonima ps nova where
    epsiloni = filter (\p -> zaZnak p == '$' && zaStanje p `elem` ss) ps
    nova = nub $ concatMap onda epsiloni ++ ss
